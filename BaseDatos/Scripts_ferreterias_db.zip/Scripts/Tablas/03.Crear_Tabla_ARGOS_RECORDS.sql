-- ============================================================
-- BASE DE DATOS: ferreterias_db
-- TABLA: ARGOS_RECORDS
-- DESCRIPCION: Almacena cada registro (contacto/cliente) del
--              archivo Excel ARGOS. Un archivo puede contener
--              multiples contactos por negocio (CODIGO_CLIENTE).
--              Incluye datos de habeas data, cargo, movil, etc.
--              Estado PROCESSED indica si fue consolidado en
--              FERRETERIASARGOS.
-- ORDEN DE CREACION: 03
-- ============================================================
USE ferreterias_db;
GO

CREATE TABLE [dbo].[ARGOS_RECORDS] (
    [ID]                        INT             NOT NULL IDENTITY(1,1),
    [FILE_ID]                   NVARCHAR(36)    NOT NULL,
    [PROCESSED]                 BIT             NULL DEFAULT ((0)),
    [CANAL]                     NVARCHAR(50)    NULL,
    [CODIGO_CLIENTE]            NVARCHAR(50)    NULL,
    [NOMBRE_CUENTA]             NVARCHAR(255)   NULL,
    [NOMBRE_OBRA]               NVARCHAR(255)   NULL,
    [NOMBRE_COMPLETO]           NVARCHAR(255)   NULL,
    [CARGO]                     NVARCHAR(100)   NULL,
    [ROL]                       NVARCHAR(100)   NULL,
    [GENERO]                    NVARCHAR(20)    NULL,
    [MOVIL]                     NVARCHAR(50)    NULL,
    [DIRECCION]                 NVARCHAR(500)   NULL,
    [MUNICIPIO]                 NVARCHAR(100)   NULL,
    [DEPARTAMENTO]              NVARCHAR(100)   NULL,
    [ES_PUNTO_VENTA_PUBLICO]    BIT             NULL,
    [HABEAS_DATA]               BIT             NULL,
    [MEDIO_AUTORIZACION_HABEAS] NVARCHAR(255)   NULL,
    [FECHA_AUTORIZACION_HABEAS] DATE            NULL,
    [HABEAS_DATA_FIRMADO]       BIT             NULL,
    [FECHA_CREACION]            DATETIME        NULL DEFAULT (GETDATE()),
    CONSTRAINT [PK_ARGOS_RECORDS] PRIMARY KEY ([ID])
);
GO
