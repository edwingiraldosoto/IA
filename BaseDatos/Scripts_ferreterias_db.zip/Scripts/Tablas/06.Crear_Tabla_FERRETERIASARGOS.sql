-- ============================================================
-- BASE DE DATOS: ferreterias_db
-- TABLA: FERRETERIASARGOS
-- DESCRIPCION: Tabla maestra de ferreterias provenientes de
--              los archivos Excel de clientes ARGOS. El campo
--              CODIGO_CLIENTE es la clave de negocio unica
--              (UNIQUE). Combina datos propios de ARGOS (canal,
--              nombre cuenta, obra) con resultados del analisis
--              de imagenes Gemini AI. Gestionada mediante el
--              patron UPSERT del SP_ARGOS_UPSERT_NEGOCIO.
-- ORDEN DE CREACION: 06
-- ============================================================
USE ferreterias_db;
GO

CREATE TABLE [dbo].[FERRETERIASARGOS] (
    [ID]                    INT             NOT NULL IDENTITY(1,1),
    [CODIGO_CLIENTE]        NVARCHAR(50)    NOT NULL,
    [NOMBRE]                NVARCHAR(255)   NULL,
    [TELEFONO]              NVARCHAR(50)    NULL,
    [WHATSAPP]              NVARCHAR(50)    NULL,
    [NIT]                   NVARCHAR(50)    NULL,
    [LAT]                   DECIMAL(10,7)   NULL,
    [LNG]                   DECIMAL(10,7)   NULL,
    [FECHA_CREACION]        DATETIME        NULL DEFAULT (GETDATE()),
    [FECHA_ACTUALIZACION]   DATETIME        NULL DEFAULT (GETDATE()),
    [VENDE_CEMENTO]         BIT             NULL DEFAULT ((0)),
    [VENDE_TUBOS]           BIT             NULL DEFAULT ((0)),
    [VENDE_VARILLAS]        BIT             NULL DEFAULT ((0)),
    [VENDE_LADRILLOS]       BIT             NULL DEFAULT ((0)),
    [VENDE_AGREGADOS]       BIT             NULL DEFAULT ((0)),
    [SCORE]                 INT             NULL DEFAULT ((0)),
    [MATERIALES_OBSERVADOS] NVARCHAR(500)   NULL,
    [NIVEL_CONFIANZA]       NVARCHAR(20)    NULL,
    [ULTIMO_ANALISIS]       DATETIME        NULL,
    [CANAL]                 NVARCHAR(50)    NULL,
    [NOMBRE_CUENTA]         NVARCHAR(255)   NULL,
    [NOMBRE_OBRA]           NVARCHAR(255)   NULL,
    [DIRECCION]             NVARCHAR(500)   NULL,
    [MUNICIPIO]             NVARCHAR(100)   NULL,
    [DEPARTAMENTO]          NVARCHAR(100)   NULL,
    [ES_PUNTO_VENTA_PUBLICO] BIT            NULL,
    [URL_GOOGLE]            NVARCHAR(500)   NULL,
    [FUENTE]                NVARCHAR(50)    NULL DEFAULT ('ARGOS'),
    CONSTRAINT [PK_FERRETERIASARGOS] PRIMARY KEY ([ID]),
    CONSTRAINT [UX_FERRETERIASARGOS_CODIGO_CLIENTE] UNIQUE ([CODIGO_CLIENTE])
);
GO
