-- ============================================================
-- BASE DE DATOS: ferreterias_db
-- TABLA: FerreteriasApify
-- DESCRIPCION: Tabla maestra de ferreterias provenientes del
--              scraping via Apify (Google Maps). Contiene datos
--              de contacto (telefono, redes sociales, sitio web),
--              coordenadas, URLs de imagenes de Google, y el
--              resultado del analisis de imagenes con Gemini AI
--              (materiales, score, nivel de confianza).
-- ORDEN DE CREACION: 05
-- ============================================================
USE ferreterias_db;
GO

CREATE TABLE [dbo].[FerreteriasApify] (
    [ID]                    INT             NOT NULL IDENTITY(1,1),
    [NOMBRE]                NVARCHAR(255)   NULL,
    [TELEFONO]              NVARCHAR(50)    NULL,
    [WHATSAPP]              NVARCHAR(50)    NULL,
    [NIT]                   NVARCHAR(50)    NULL,
    [LAT]                   DECIMAL(10,7)   NULL,
    [LNG]                   DECIMAL(10,7)   NULL,
    [URL_GOOGLE]            NVARCHAR(MAX)   NULL,
    [URLS_IMAGENES]         NVARCHAR(MAX)   NULL,
    [FACEBOOK]              NVARCHAR(255)   NULL,
    [INSTAGRAM]             NVARCHAR(255)   NULL,
    [FECHA_CREACION]        DATETIME        NULL DEFAULT (GETDATE()),
    [FECHA_ACTUALIZACION]   DATETIME        NULL DEFAULT (GETDATE()),
    [VENDE_CEMENTO]         BIT             NULL DEFAULT ((0)),
    [VENDE_TUBOS]           BIT             NULL DEFAULT ((0)),
    [VENDE_VARILLAS]        BIT             NULL DEFAULT ((0)),
    [VENDE_LADRILLOS]       BIT             NULL DEFAULT ((0)),
    [VENDE_AGREGADOS]       BIT             NULL DEFAULT ((0)),
    [SCORE]                 INT             NULL DEFAULT ((0)),
    [MATERIALES_OBSERVADOS] NVARCHAR(500)   NULL,
    [NIVEL_CONFIANZA]       NVARCHAR(20)    NULL,
    [ULTIMO_ANALISIS]       DATETIME        NULL,
    [DEPARTAMENTO]          NVARCHAR(100)   NULL,
    [MUNICIPIO]             NVARCHAR(100)   NULL,
    [DIRECCION_COMERCIAL]   NVARCHAR(500)   NULL,
    [CORREO_COMERCIAL]      NVARCHAR(255)   NULL,
    [SITIO_WEB]             NVARCHAR(255)   NULL,
    CONSTRAINT [PK_FerreteriasApify] PRIMARY KEY ([ID])
);
GO
