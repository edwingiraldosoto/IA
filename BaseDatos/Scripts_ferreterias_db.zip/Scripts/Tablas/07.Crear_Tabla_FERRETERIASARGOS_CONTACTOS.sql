-- ============================================================
-- BASE DE DATOS: ferreterias_db
-- TABLA: FERRETERIASARGOS_CONTACTOS
-- DESCRIPCION: Contactos asociados a cada ferreteria en
--              FERRETERIASARGOS. Un negocio puede tener
--              multiples contactos con diferentes cargos/roles.
--              Almacena informacion de habeas data y autorizacion
--              de cada persona. Relacionada via FK con
--              FERRETERIASARGOS.ID.
-- ORDEN DE CREACION: 07 (depende de FERRETERIASARGOS)
-- ============================================================
USE ferreterias_db;
GO

CREATE TABLE [dbo].[FERRETERIASARGOS_CONTACTOS] (
    [ID]                        INT             NOT NULL IDENTITY(1,1),
    [FERRETERIA_ID]             INT             NOT NULL,
    [CODIGO_CLIENTE]            NVARCHAR(50)    NULL,
    [NOMBRE_COMPLETO]           NVARCHAR(255)   NULL,
    [CARGO]                     NVARCHAR(100)   NULL,
    [ROL]                       NVARCHAR(100)   NULL,
    [GENERO]                    NVARCHAR(20)    NULL,
    [MOVIL]                     NVARCHAR(50)    NULL,
    [HABEAS_DATA]               BIT             NULL,
    [MEDIO_AUTORIZACION_HABEAS] NVARCHAR(255)   NULL,
    [FECHA_AUTORIZACION_HABEAS] DATE            NULL,
    [HABEAS_DATA_FIRMADO]       BIT             NULL,
    [FECHA_CREACION]            DATETIME        NULL DEFAULT (GETDATE()),
    CONSTRAINT [PK_FERRETERIASARGOS_CONTACTOS] PRIMARY KEY ([ID]),
    CONSTRAINT [FK_CONTACTOS_FERRETERIA] FOREIGN KEY ([FERRETERIA_ID])
        REFERENCES [FERRETERIASARGOS]([ID])
);
GO
