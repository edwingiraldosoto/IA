-- ============================================================
-- BASE DE DATOS: ferreterias_db
-- TABLA: RUES_RECORDS
-- DESCRIPCION: Almacena cada registro de empresa extraido de
--              un archivo Excel del RUES. Incluye datos de
--              identificacion, ubicacion, coordenadas y estado
--              de procesamiento (analisis de Street View).
-- ORDEN DE CREACION: 01 (depende de RUES_UPLOADS via FK)
-- ============================================================
USE ferreterias_db;
GO

CREATE TABLE [dbo].[RUES_RECORDS] (
    [RECORD_ID]             INT            NOT NULL IDENTITY(1,1),
    [FILE_ID]               VARCHAR(36)    NOT NULL,
    [RAZON_SOCIAL]          VARCHAR(500)   NULL,
    [NUMERO_IDENTIFICACION] VARCHAR(50)    NULL,
    [TIPO_IDENTIFICACION]   VARCHAR(50)    NULL,
    [DEPARTAMENTO]          VARCHAR(100)   NULL,
    [MUNICIPIO]             VARCHAR(100)   NULL,
    [DIRECCION_COMERCIAL]   VARCHAR(500)   NULL,
    [CORREO_COMERCIAL]      VARCHAR(255)   NULL,
    [REP_LEGAL]             VARCHAR(255)   NULL,
    [LATITUD]               DECIMAL(10,7)  NULL,
    [LONGITUD]              DECIMAL(10,7)  NULL,
    [PROCESSED]             BIT            NULL DEFAULT ((0)),
    [PROCESSED_AT]          DATETIME       NULL,
    CONSTRAINT [PK__RUES_REC__E2DA602F4441BF12] PRIMARY KEY ([RECORD_ID]),
    CONSTRAINT [FK_RUES_RECORDS_UPLOAD] FOREIGN KEY ([FILE_ID])
        REFERENCES [RUES_UPLOADS]([FILE_ID])
);
GO
