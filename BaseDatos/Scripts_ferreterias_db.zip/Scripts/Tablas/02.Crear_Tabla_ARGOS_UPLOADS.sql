-- ============================================================
-- BASE DE DATOS: ferreterias_db
-- TABLA: ARGOS_UPLOADS
-- DESCRIPCION: Control de archivos Excel cargados con datos
--              de clientes ARGOS. Equivalente a RUES_UPLOADS
--              pero para el dominio ARGOS. Registra el estado,
--              hash, contadores de progreso y resumen geografico
--              de departamentos/municipios del archivo.
-- ORDEN DE CREACION: 02
-- ============================================================
USE ferreterias_db;
GO

CREATE TABLE [dbo].[ARGOS_UPLOADS] (
    [ID]                   INT             NOT NULL IDENTITY(1,1),
    [file_id]              NVARCHAR(36)    NOT NULL,
    [filename]             NVARCHAR(255)   NULL,
    [hash_archivo]         NVARCHAR(32)    NULL,
    [status]               NVARCHAR(20)    NULL,
    [fecha_upload]         DATETIME        NULL DEFAULT (GETDATE()),
    [TOTAL_REGISTROS]      INT             NULL DEFAULT ((0)),
    [REGISTROS_PROCESADOS] INT             NULL DEFAULT ((0)),
    [MENSAJE]              NVARCHAR(MAX)   NULL,
    [FECHA_ACTUALIZACION]  DATETIME        NULL DEFAULT (GETDATE()),
    [DEPARTAMENTOS]        NVARCHAR(500)   NULL,
    [MUNICIPIOS]           NVARCHAR(500)   NULL,
    CONSTRAINT [PK_ARGOS_UPLOADS] PRIMARY KEY ([ID])
);
GO
