-- ============================================================
-- BASE DE DATOS: ferreterias_db
-- TABLA: SyncJobs
-- DESCRIPCION: Control de ejecuciones del proceso de
--              sincronizacion/unificacion de ferreterias.
--              Cada job unifica los datos de FERRETERIASRUES,
--              FerreteriasApify y FERRETERIASARGOS en la tabla
--              FerreteriasUnificadas. Registra contadores por
--              fuente, posicion en cola, fechas de inicio/fin
--              y mensaje de resultado.
-- ORDEN DE CREACION: 08
-- ============================================================
USE ferreterias_db;
GO

CREATE TABLE [dbo].[SyncJobs] (
    [ID]               INT             NOT NULL IDENTITY(1,1),
    [JOB_ID]           NVARCHAR(50)    NOT NULL,
    [STATUS]           NVARCHAR(20)    NULL DEFAULT ('pendiente'),
    [TOTAL_RUES]       INT             NULL DEFAULT ((0)),
    [TOTAL_APIFY]      INT             NULL DEFAULT ((0)),
    [TOTAL_UNIFICADOS] INT             NULL DEFAULT ((0)),
    [TOTAL_SOLO_RUES]  INT             NULL DEFAULT ((0)),
    [TOTAL_SOLO_APIFY] INT             NULL DEFAULT ((0)),
    [POSICION_COLA]    INT             NULL DEFAULT ((0)),
    [FECHA_INICIO]     DATETIME        NULL DEFAULT (GETDATE()),
    [FECHA_FIN]        DATETIME        NULL,
    [MENSAJE]          NVARCHAR(500)   NULL,
    [TOTAL_ARGOS]      INT             NULL DEFAULT ((0)),
    [TOTAL_SOLO_ARGOS] INT             NULL DEFAULT ((0)),
    CONSTRAINT [PK_SyncJobs] PRIMARY KEY ([ID])
);
GO
