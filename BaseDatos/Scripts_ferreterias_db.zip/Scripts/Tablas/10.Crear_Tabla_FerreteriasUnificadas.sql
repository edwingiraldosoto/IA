-- ============================================================
-- BASE DE DATOS: ferreterias_db
-- TABLA: FerreteriasUnificadas
-- DESCRIPCION: Tabla consolidada (golden record) que unifica
--              datos de las tres fuentes: FERRETERIASRUES,
--              FerreteriasApify y FERRETERIASARGOS. La columna
--              FUENTE indica el origen principal del registro
--              y los campos ID_RUES, ID_APIFY, ID_ARGOS
--              mantienen la trazabilidad hacia las tablas fuente.
--              SCORE_FUZZY refleja la similitud usada durante
--              el proceso de matching en la sincronizacion.
--              Esta es la tabla consumida por el modulo Mapa
--              del frontend.
-- ORDEN DE CREACION: 10 (depende de FERRETERIASARGOS via FK)
-- ============================================================
USE ferreterias_db;
GO

CREATE TABLE [dbo].[FerreteriasUnificadas] (
    [ID]                        INT             NOT NULL IDENTITY(1,1),
    [NOMBRE]                    NVARCHAR(255)   NULL,
    [TELEFONO]                  NVARCHAR(50)    NULL,
    [WHATSAPP]                  NVARCHAR(50)    NULL,
    [NIT]                       NVARCHAR(50)    NULL,
    [LAT]                       DECIMAL(10,7)   NULL,
    [LNG]                       DECIMAL(10,7)   NULL,
    [URL_GOOGLE]                NVARCHAR(MAX)   NULL,
    [URLS_IMAGENES]             NVARCHAR(MAX)   NULL,
    [FACEBOOK]                  NVARCHAR(255)   NULL,
    [INSTAGRAM]                 NVARCHAR(255)   NULL,
    [SITIO_WEB]                 NVARCHAR(255)   NULL,
    [FECHA_CREACION]            DATETIME        NULL DEFAULT (GETDATE()),
    [FECHA_ACTUALIZACION]       DATETIME        NULL DEFAULT (GETDATE()),
    [VENDE_CEMENTO]             BIT             NULL DEFAULT ((0)),
    [VENDE_TUBOS]               BIT             NULL DEFAULT ((0)),
    [VENDE_VARILLAS]            BIT             NULL DEFAULT ((0)),
    [VENDE_LADRILLOS]           BIT             NULL DEFAULT ((0)),
    [VENDE_AGREGADOS]           BIT             NULL DEFAULT ((0)),
    [SCORE]                     INT             NULL DEFAULT ((0)),
    [MATERIALES_OBSERVADOS]     NVARCHAR(500)   NULL,
    [NIVEL_CONFIANZA]           NVARCHAR(20)    NULL,
    [ULTIMO_ANALISIS]           DATETIME        NULL,
    [DEPARTAMENTO]              NVARCHAR(100)   NULL,
    [MUNICIPIO]                 NVARCHAR(100)   NULL,
    [DIRECCION_COMERCIAL]       NVARCHAR(500)   NULL,
    [CORREO_COMERCIAL]          NVARCHAR(255)   NULL,
    [REP_LEGAL_RUES]            NVARCHAR(255)   NULL,
    [RAZON_SOCIAL_RUES]         NVARCHAR(500)   NULL,
    [TIPO_IDENTIFICACION_RUES]  NVARCHAR(100)   NULL,
    [NUMERO_IDENTIFICACION_RUES] NVARCHAR(50)   NULL,
    [ID_RUES]                   INT             NULL,
    [ID_APIFY]                  INT             NULL,
    [FUENTE]                    NVARCHAR(20)    NULL,
    [SCORE_FUZZY]               DECIMAL(5,2)    NULL,
    [ID_ARGOS]                  INT             NULL,
    [CODIGO_CLIENTE_ARGOS]      NVARCHAR(50)    NULL,
    [CANAL]                     NVARCHAR(50)    NULL,
    [NOMBRE_CUENTA]             NVARCHAR(255)   NULL,
    [NOMBRE_OBRA]               NVARCHAR(255)   NULL,
    [ES_PUNTO_VENTA_PUBLICO]    BIT             NULL DEFAULT ((0)),
    CONSTRAINT [PK_FerreteriasUnificadas] PRIMARY KEY ([ID]),
    CONSTRAINT [FK_FU_ARGOS] FOREIGN KEY ([ID_ARGOS])
        REFERENCES [FERRETERIASARGOS]([ID])
);
GO
