-- ============================================================
-- BASE DE DATOS: ferreterias_db
-- TABLA: FerreteriasUnificadas_Contactos
-- DESCRIPCION: Contactos consolidados asociados a los negocios
--              en FerreteriasUnificadas. Referencia el contacto
--              original de FERRETERIASARGOS_CONTACTOS via
--              FERRETERIA_ARGOS_CONTACTO_ID para trazabilidad.
-- ORDEN DE CREACION: 11 (depende de FerreteriasUnificadas y
--                        FERRETERIASARGOS_CONTACTOS via FK)
-- ============================================================
USE ferreterias_db;
GO

CREATE TABLE [dbo].[FerreteriasUnificadas_Contactos] (
    [ID]                          INT             NOT NULL IDENTITY(1,1),
    [FERRETERIA_UNIFICADA_ID]     INT             NOT NULL,
    [FERRETERIA_ARGOS_CONTACTO_ID] INT            NULL,
    [NOMBRE_COMPLETO]             NVARCHAR(255)   NULL,
    [CARGO]                       NVARCHAR(100)   NULL,
    [MOVIL]                       NVARCHAR(50)    NULL,
    [GENERO]                      NVARCHAR(20)    NULL,
    [HABEAS_DATA]                 BIT             NULL,
    [FECHA_CREACION]              DATETIME        NULL DEFAULT (GETDATE()),
    [CODIGO_CLIENTE_ARGOS]        NVARCHAR(50)    NULL,
    CONSTRAINT [PK_FU_CONTACTOS] PRIMARY KEY ([ID]),
    CONSTRAINT [FK_FU_CONTACTOS_UNIFICADA] FOREIGN KEY ([FERRETERIA_UNIFICADA_ID])
        REFERENCES [FerreteriasUnificadas]([ID]),
    CONSTRAINT [FK_FU_CONTACTOS_ARGOS] FOREIGN KEY ([FERRETERIA_ARGOS_CONTACTO_ID])
        REFERENCES [FERRETERIASARGOS_CONTACTOS]([ID])
);
GO
