-- ============================================================
-- BASE DE DATOS: ferreterias_db
-- TABLA: FERRETERIASRUES
-- DESCRIPCION: Tabla maestra de ferreterias provenientes del
--              procesamiento del RUES. Consolida datos del RUES
--              (razon social, NIT, representante legal) con el
--              resultado del analisis de imagenes de Street View
--              via Gemini AI (materiales observados, score,
--              nivel de confianza). Es la tabla destino del
--              SP_GUARDARRESULTADOFINAL.
-- ORDEN DE CREACION: 04
-- ============================================================
USE ferreterias_db;
GO

CREATE TABLE [dbo].[FERRETERIASRUES] (
    [ID]                        INT             NOT NULL IDENTITY(1,1),
    [NOMBRE]                    NVARCHAR(255)   NULL,
    [TELEFONO]                  NVARCHAR(50)    NULL,
    [WHATSAPP]                  NVARCHAR(50)    NULL,
    [NIT]                       NVARCHAR(50)    NULL,
    [LAT]                       DECIMAL(10,7)   NULL,
    [LNG]                       DECIMAL(10,7)   NULL,
    [FECHA_CREACION]            DATETIME        NULL DEFAULT (GETDATE()),
    [FECHA_ACTUALIZACION]       DATETIME        NULL DEFAULT (GETDATE()),
    [VENDE_CEMENTO]             BIT             NULL DEFAULT ((0)),
    [VENDE_TUBOS]               BIT             NULL DEFAULT ((0)),
    [VENDE_VARILLAS]            BIT             NULL DEFAULT ((0)),
    [VENDE_LADRILLOS]           BIT             NULL DEFAULT ((0)),
    [VENDE_AGREGADOS]           BIT             NULL DEFAULT ((0)),
    [SCORE]                     INT             NULL DEFAULT ((0)),
    [MATERIALES_OBSERVADOS]     NVARCHAR(500)   NULL,
    [NIVEL_CONFIANZA]           NVARCHAR(20)    NULL,
    [ULTIMO_ANALISIS]           DATETIME        NULL,
    [RAZON_SOCIAL_RUES]         NVARCHAR(500)   NULL,
    [TIPO_IDENTIFICACION_RUES]  NVARCHAR(100)   NULL,
    [NUMERO_IDENTIFICACION_RUES] NVARCHAR(50)   NULL,
    [DEPARTAMENTO_RUES]         NVARCHAR(100)   NULL,
    [MUNICIPIO_RUES]            NVARCHAR(100)   NULL,
    [DIRECCION_COMERCIAL_RUES]  NVARCHAR(500)   NULL,
    [CORREO_COMERCIAL_RUES]     NVARCHAR(255)   NULL,
    [REP_LEGAL_RUES]            NVARCHAR(255)   NULL,
    CONSTRAINT [PK_FERRETERIAS] PRIMARY KEY ([ID])
);
GO
