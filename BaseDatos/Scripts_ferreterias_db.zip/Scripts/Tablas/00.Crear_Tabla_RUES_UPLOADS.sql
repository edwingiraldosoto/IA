-- ============================================================
-- BASE DE DATOS: ferreterias_db
-- TABLA: RUES_UPLOADS
-- DESCRIPCION: Control de archivos Excel cargados del RUES.
--              Almacena el estado del procesamiento de cada
--              archivo, su hash para evitar duplicados y
--              contadores de progreso.
-- ORDEN DE CREACION: 00 (base del dominio RUES)
-- ============================================================
USE ferreterias_db;
GO

CREATE TABLE [dbo].[RUES_UPLOADS] (
    [FILE_ID]              VARCHAR(36)    NOT NULL,
    [FILENAME]             VARCHAR(255)   NOT NULL,
    [HASH_ARCHIVO]         VARCHAR(64)    NOT NULL,
    [STATUS]               VARCHAR(20)    NULL DEFAULT ('PROCESSING'),
    [TOTAL_RECORDS]        INT            NULL DEFAULT ((0)),
    [CREATED_AT]           DATETIME       NULL DEFAULT (GETDATE()),
    [UPDATED_AT]           DATETIME       NULL DEFAULT (GETDATE()),
    [REGISTROS_PROCESADOS] INT            NULL DEFAULT ((0)),
    [MENSAJE]              NVARCHAR(MAX)  NULL,
    [FECHA_ACTUALIZACION]  DATETIME       NULL DEFAULT (GETDATE()),
    [DEPARTAMENTOS]        VARCHAR(MAX)   NULL,
    [MUNICIPIOS]           VARCHAR(MAX)   NULL,
    CONSTRAINT [PK__RUES_UPL__49C04C7A778D056D] PRIMARY KEY ([FILE_ID])
);
GO
