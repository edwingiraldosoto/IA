-- ============================================================
-- BASE DE DATOS: ferreterias_db
-- TABLA: SyncJobs_Descartados
-- DESCRIPCION: Log de registros descartados durante un proceso
--              de sincronizacion. Almacena el JOB_ID que los
--              genero, nombre del negocio, fuente de origen y
--              motivo del descarte. Util para auditoria.
-- ORDEN DE CREACION: 09
-- ============================================================
USE ferreterias_db;
GO

CREATE TABLE [dbo].[SyncJobs_Descartados] (
    [ID]             INT             NOT NULL IDENTITY(1,1),
    [JOB_ID]         NVARCHAR(50)    NOT NULL,
    [NOMBRE]         NVARCHAR(255)   NULL,
    [FUENTE]         NVARCHAR(20)    NULL,
    [MOTIVO]         NVARCHAR(100)   NULL,
    [FECHA_REGISTRO] DATETIME        NULL DEFAULT (GETDATE()),
    CONSTRAINT [PK_DESCARTADOS] PRIMARY KEY ([ID])
);
GO
