-- ============================================================
-- BASE DE DATOS: ferreterias_db
-- PROCEDIMIENTO: SP_MAPA_RESUMEN_MATERIALES
-- DESCRIPCION: Retorna los flags de venta de cemento y los
--              materiales observados por Gemini AI de todos
--              los negocios, con filtros opcionales de
--              departamento/municipio. Usado por el frontend
--              para generar graficas de resumen sobre que
--              materiales se comercializan en una zona.
-- PARAMETROS:
--   @DEPARTAMENTO - Filtro de departamento (NULL=todos)
--   @MUNICIPIO    - Filtro de municipio (NULL=todos)
-- DOMINIO: Mapa / Negocios
-- ============================================================
USE ferreterias_db;
GO

CREATE PROCEDURE [dbo].[SP_MAPA_RESUMEN_MATERIALES]
    @DEPARTAMENTO NVARCHAR(100) = NULL,
    @MUNICIPIO    NVARCHAR(100) = NULL
AS
BEGIN
    SET NOCOUNT ON;

    SELECT VENDE_CEMENTO, MATERIALES_OBSERVADOS
    FROM FerreteriasUnificadas
    WHERE
        (DEPARTAMENTO = @DEPARTAMENTO OR @DEPARTAMENTO IS NULL)
        AND (MUNICIPIO = @MUNICIPIO OR @MUNICIPIO IS NULL);
END;
GO
