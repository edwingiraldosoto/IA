-- ============================================================
-- BASE DE DATOS: ferreterias_db
-- PROCEDIMIENTO: SP_MARCARREGISTROPROCESADO
-- DESCRIPCION: Marca un registro de RUES_RECORDS como procesado
--              (PROCESSED=1) y registra la fecha y hora del
--              procesamiento. Llamado por el pipeline de Node.js
--              despues de analizar exitosamente las imagenes de
--              Street View de un negocio con Gemini AI.
-- PARAMETROS:
--   @RECORD_ID - ID del registro en RUES_RECORDS
-- DOMINIO: RUES - Procesamiento
-- ============================================================
USE ferreterias_db;
GO

CREATE PROCEDURE [dbo].[SP_MARCARREGISTROPROCESADO]
    @RECORD_ID INT
AS
BEGIN
    UPDATE RUES_RECORDS
    SET PROCESSED = 1,
        PROCESSED_AT = GETDATE()
    WHERE RECORD_ID = @RECORD_ID;
END;
GO
