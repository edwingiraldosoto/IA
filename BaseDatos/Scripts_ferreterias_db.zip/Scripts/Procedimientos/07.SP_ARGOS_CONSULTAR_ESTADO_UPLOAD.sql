-- ============================================================
-- BASE DE DATOS: ferreterias_db
-- PROCEDIMIENTO: SP_ARGOS_CONSULTAR_ESTADO_UPLOAD
-- DESCRIPCION: Consulta el estado de un upload ARGOS y el
--              progreso de sus registros. Equivalente a
--              SP_RUES_CONSULTAR_ESTADO pero sobre las tablas
--              ARGOS_UPLOADS y ARGOS_RECORDS.
--              Devuelve dos result sets:
--              RS1 - Estado general (status, filename, fecha_upload)
--              RS2 - Conteo total y procesados de ARGOS_RECORDS
-- PARAMETROS:
--   @FILE_ID - UUID del archivo
-- DOMINIO: ARGOS - Uploads/Estado
-- ============================================================
USE ferreterias_db;
GO

CREATE PROCEDURE [dbo].[SP_ARGOS_CONSULTAR_ESTADO_UPLOAD]
    @FILE_ID NVARCHAR(36)
AS
BEGIN
    SET NOCOUNT ON;

    -- Resultado 1: Estado del upload
    SELECT status, filename, fecha_upload
    FROM argos_uploads
    WHERE file_id = @FILE_ID;

    -- Resultado 2: Conteos de registros
    SELECT
        COUNT(*) AS total,
        SUM(CASE WHEN processed = 1 THEN 1 ELSE 0 END) AS procesados
    FROM argos_records
    WHERE file_id = @FILE_ID;
END;
GO
