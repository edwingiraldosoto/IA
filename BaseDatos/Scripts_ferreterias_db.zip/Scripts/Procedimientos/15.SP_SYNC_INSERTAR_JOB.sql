-- ============================================================
-- BASE DE DATOS: ferreterias_db
-- PROCEDIMIENTO: SP_SYNC_INSERTAR_JOB
-- DESCRIPCION: Registra un nuevo job de sincronizacion en
--              SyncJobs con estado inicial 'pendiente' y su
--              posicion en la cola de procesamiento. El JOB_ID
--              es un identificador UUID generado por el backend.
-- PARAMETROS:
--   @JOB_ID   - UUID del job generado por el backend
--   @POSICION - Posicion en la cola de ejecucion (1=primero)
-- DOMINIO: Sincronizacion
-- ============================================================
USE ferreterias_db;
GO

CREATE PROCEDURE [dbo].[SP_SYNC_INSERTAR_JOB]
    @JOB_ID   NVARCHAR(50),
    @POSICION INT
AS
BEGIN
    SET NOCOUNT ON;

    INSERT INTO SyncJobs (JOB_ID, STATUS, POSICION_COLA)
    VALUES (@JOB_ID, 'pendiente', @POSICION);
END;
GO
