-- ============================================================
-- BASE DE DATOS: ferreterias_db
-- PROCEDIMIENTO: SP_MAPA_OPCIONES_FILTROS
-- DESCRIPCION: Devuelve 5 result sets con los valores distintos
--              disponibles para los filtros del mapa. Solo incluye
--              registros que tengan coordenadas (LAT/LNG no nulas).
--              RS1 - Departamentos disponibles (ORDER BY nombre)
--              RS2 - Municipios con su departamento
--              RS3 - Fuentes disponibles (RUES/APIFY/ARGOS/mixtas)
--              RS4 - Niveles de confianza disponibles (AI)
--              RS5 - Total de negocios con coordenadas en el mapa
-- SIN PARAMETROS
-- DOMINIO: Mapa / Negocios
-- ============================================================
USE ferreterias_db;
GO

CREATE PROCEDURE [dbo].[SP_MAPA_OPCIONES_FILTROS]
AS
BEGIN
    SET NOCOUNT ON;

    -- RS1: Departamentos
    SELECT DISTINCT DEPARTAMENTO
    FROM FerreteriasUnificadas
    WHERE LAT IS NOT NULL AND LNG IS NOT NULL
      AND DEPARTAMENTO IS NOT NULL
    ORDER BY DEPARTAMENTO;

    -- RS2: Municipios por departamento
    SELECT DISTINCT MUNICIPIO, DEPARTAMENTO
    FROM FerreteriasUnificadas
    WHERE LAT IS NOT NULL AND LNG IS NOT NULL
      AND MUNICIPIO IS NOT NULL
    ORDER BY DEPARTAMENTO, MUNICIPIO;

    -- RS3: Fuentes
    SELECT DISTINCT FUENTE
    FROM FerreteriasUnificadas
    WHERE LAT IS NOT NULL AND LNG IS NOT NULL
      AND FUENTE IS NOT NULL;

    -- RS4: Niveles de confianza
    SELECT DISTINCT NIVEL_CONFIANZA
    FROM FerreteriasUnificadas
    WHERE LAT IS NOT NULL AND LNG IS NOT NULL
      AND NIVEL_CONFIANZA IS NOT NULL;

    -- RS5: Total con coordenadas
    SELECT COUNT(*) AS total
    FROM FerreteriasUnificadas
    WHERE LAT IS NOT NULL AND LNG IS NOT NULL;
END;
GO
