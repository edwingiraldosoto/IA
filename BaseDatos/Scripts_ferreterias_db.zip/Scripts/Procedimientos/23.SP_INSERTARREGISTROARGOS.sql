-- ============================================================
-- BASE DE DATOS: ferreterias_db
-- PROCEDIMIENTO: SP_INSERTARREGISTROARGOS
-- DESCRIPCION: Version anterior (legacy) de SP_ARGOS_INSERTAR_REGISTROS.
--              Inserta un registro de contacto ARGOS en
--              ARGOS_RECORDS. Esta version incluye campos
--              adicionales (POBLACION, DEPARTAMENTO_TEXTO) que
--              fueron refactorizados en la version actual.
--              Conservado por compatibilidad con versiones
--              anteriores del backend.
-- PARAMETROS: Similar a SP_ARGOS_INSERTAR_REGISTROS con campos
--             POBLACION y DEPARTAMENTO_TEXTO adicionales.
-- DOMINIO: ARGOS - Carga masiva (version legacy)
-- ============================================================
USE ferreterias_db;
GO

CREATE PROCEDURE [dbo].[SP_INSERTARREGISTROARGOS]
    @FILE_ID                   NVARCHAR(36),
    @CANAL                     NVARCHAR(50),
    @CODIGO_CLIENTE            NVARCHAR(50),
    @NOMBRE_CUENTA             NVARCHAR(255),
    @NOMBRE_OBRA               NVARCHAR(255),
    @NOMBRE_COMPLETO           NVARCHAR(255),
    @DIRECCION                 NVARCHAR(500),
    @POBLACION                 NVARCHAR(100),
    @DEPARTAMENTO_TEXTO        NVARCHAR(100),
    @CARGO                     NVARCHAR(100),
    @ROL                       NVARCHAR(100),
    @GENERO                    NVARCHAR(20),
    @DEPARTAMENTO              NVARCHAR(100),
    @MOVIL                     NVARCHAR(50),
    @HABEAS_DATA               BIT,
    @MEDIO_AUTORIZACION_HABEAS NVARCHAR(255),
    @FECHA_AUTORIZACION_HABEAS DATE,
    @ES_PUNTO_VENTA_PUBLICO    BIT,
    @HABEAS_DATA_FIRMADO       BIT
AS
BEGIN
    SET NOCOUNT ON;

    INSERT INTO [dbo].[ARGOS_RECORDS] (
        FILE_ID, CANAL, CODIGO_CLIENTE, NOMBRE_CUENTA, NOMBRE_OBRA,
        NOMBRE_COMPLETO, CARGO, ROL, GENERO, DEPARTAMENTO,
        MOVIL, HABEAS_DATA, MEDIO_AUTORIZACION_HABEAS,
        FECHA_AUTORIZACION_HABEAS, ES_PUNTO_VENTA_PUBLICO,
        HABEAS_DATA_FIRMADO, PROCESSED
    ) VALUES (
        @FILE_ID, @CANAL, @CODIGO_CLIENTE, @NOMBRE_CUENTA, @NOMBRE_OBRA,
        @NOMBRE_COMPLETO, @CARGO, @ROL, @GENERO, @DEPARTAMENTO,
        @MOVIL, @HABEAS_DATA, @MEDIO_AUTORIZACION_HABEAS,
        @FECHA_AUTORIZACION_HABEAS, @ES_PUNTO_VENTA_PUBLICO,
        @HABEAS_DATA_FIRMADO, 0
    );
END;
GO
