-- ============================================================
-- BASE DE DATOS: ferreterias_db
-- PROCEDIMIENTO: SP_ARGOS_VERIFICAR_Y_REGISTRAR_UPLOAD
-- DESCRIPCION: Equivalente de SP_RUES_VERIFICAR_Y_REGISTRAR_UPLOAD
--              pero para el dominio ARGOS. Verifica por hash si
--              el archivo Excel de clientes ARGOS ya fue cargado
--              y registra un nuevo upload en ARGOS_UPLOADS si
--              es la primera vez que se sube ese archivo.
-- PARAMETROS:
--   @FILE_ID, @FILENAME, @HASH_ARCHIVO (entrada)
--   @EXISTE, @STATUS_ANTERIOR (salida OUTPUT)
-- DOMINIO: ARGOS - Uploads/Estado
-- ============================================================
USE ferreterias_db;
GO

CREATE PROCEDURE [dbo].[SP_ARGOS_VERIFICAR_Y_REGISTRAR_UPLOAD]
    @FILE_ID         NVARCHAR(36),
    @FILENAME        NVARCHAR(255),
    @HASH_ARCHIVO    NVARCHAR(32),
    @EXISTE          INT OUTPUT,
    @STATUS_ANTERIOR NVARCHAR(20) OUTPUT
AS
BEGIN
    SET NOCOUNT ON;

    DECLARE @RowCount INT;

    SELECT @STATUS_ANTERIOR = status, @RowCount = COUNT(*)
    FROM argos_uploads
    WHERE hash_archivo = @HASH_ARCHIVO
      AND status IN ('processing', 'completed')
    GROUP BY status;

    SET @EXISTE = ISNULL(@RowCount, 0);

    IF @EXISTE = 0
    BEGIN
        INSERT INTO argos_uploads (file_id, filename, hash_archivo, status)
        VALUES (@FILE_ID, @FILENAME, @HASH_ARCHIVO, 'processing');
    END
END;
GO
