-- ============================================================
-- BASE DE DATOS: ferreterias_db
-- PROCEDIMIENTO: SP_BUSCAR_FERRETERIAS
-- DESCRIPCION: Busca ferreterias en un radio de distancia desde
--              un punto de coordenadas dado, usando la formula
--              de Haversine para calcular la distancia en km.
--              Permite filtrar solo las que venden cemento.
--              Retorna las ferreterias ordenadas de mas cercana
--              a mas lejana junto con la distancia calculada.
-- NOTA: Hace referencia a la tabla FERRETERIAS (nombre original
--       antes de FERRETERIASRUES). Verificar en el ambiente.
-- PARAMETROS:
--   @LAT, @LNG     - Punto de busqueda
--   @RADIO_KM      - Radio en km (por defecto 5)
--   @SOLO_CEMENTO  - 1=solo vendedoras de cemento, 0=todas
-- DOMINIO: Consultas / Mapa (version legacy)
-- ============================================================
USE ferreterias_db;
GO

CREATE PROCEDURE [dbo].[SP_BUSCAR_FERRETERIAS]
    @LAT          DECIMAL(10,7),
    @LNG          DECIMAL(10,7),
    @RADIO_KM     INT = 5,
    @SOLO_CEMENTO BIT = 0
AS
BEGIN
    SET NOCOUNT ON;

    -- Formula Haversine para calcular distancia en km
    SELECT
        ID,
        NOMBRE,
        TELEFONO,
        WHATSAPP,
        LAT,
        LNG,
        VENDE_CEMENTO,
        VENDE_TUBOS,
        VENDE_VARILLAS,
        SCORE,
        MATERIALES_OBSERVADOS,
        6371 * ACOS(
            COS(RADIANS(@LAT)) * COS(RADIANS(LAT)) *
            COS(RADIANS(LNG) - RADIANS(@LNG)) +
            SIN(RADIANS(@LAT)) * SIN(RADIANS(LAT))
        ) AS DISTANCIA_KM
    FROM FERRETERIAS
    WHERE
        (@SOLO_CEMENTO = 0 OR VENDE_CEMENTO = 1)
        AND LAT IS NOT NULL
        AND LNG IS NOT NULL
    ORDER BY DISTANCIA_KM ASC;
END;
GO
