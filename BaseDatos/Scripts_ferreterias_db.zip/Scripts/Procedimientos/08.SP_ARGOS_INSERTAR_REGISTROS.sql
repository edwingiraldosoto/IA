-- ============================================================
-- BASE DE DATOS: ferreterias_db
-- PROCEDIMIENTO: SP_ARGOS_INSERTAR_REGISTROS
-- DESCRIPCION: Inserta un registro individual de contacto/cliente
--              ARGOS en ARGOS_RECORDS. Llamado en carga masiva
--              al procesar cada fila del Excel ARGOS. Cada fila
--              representa un contacto (persona) asociado a un
--              negocio (CODIGO_CLIENTE). Un negocio puede generar
--              multiples registros por tener varios contactos.
-- PARAMETROS: Campos del archivo ARGOS incluyendo datos del
--             negocio, datos del contacto y habeas data.
-- DOMINIO: ARGOS - Carga masiva
-- ============================================================
USE ferreterias_db;
GO

CREATE PROCEDURE [dbo].[SP_ARGOS_INSERTAR_REGISTROS]
    @FILE_ID                    NVARCHAR(36),
    @CANAL                      NVARCHAR(50),
    @CODIGO_CLIENTE             NVARCHAR(50),
    @NOMBRE_CUENTA              NVARCHAR(255),
    @NOMBRE_OBRA                NVARCHAR(255),
    @NOMBRE_COMPLETO            NVARCHAR(255),
    @CARGO                      NVARCHAR(100),
    @ROL                        NVARCHAR(100),
    @GENERO                     NVARCHAR(20),
    @MOVIL                      NVARCHAR(50),
    @DIRECCION                  NVARCHAR(500),
    @MUNICIPIO                  NVARCHAR(100),
    @DEPARTAMENTO               NVARCHAR(100),
    @ES_PUNTO_VENTA_PUBLICO     BIT,
    @HABEAS_DATA                BIT,
    @MEDIO_AUTORIZACION_HABEAS  NVARCHAR(255),
    @FECHA_AUTORIZACION_HABEAS  DATE,
    @HABEAS_DATA_FIRMADO        BIT
AS
BEGIN
    SET NOCOUNT ON;

    INSERT INTO ARGOS_RECORDS (
        FILE_ID, CANAL, CODIGO_CLIENTE, NOMBRE_CUENTA, NOMBRE_OBRA,
        NOMBRE_COMPLETO, CARGO, ROL, GENERO, MOVIL,
        DIRECCION, MUNICIPIO, DEPARTAMENTO, ES_PUNTO_VENTA_PUBLICO,
        HABEAS_DATA, MEDIO_AUTORIZACION_HABEAS,
        FECHA_AUTORIZACION_HABEAS, HABEAS_DATA_FIRMADO
    ) VALUES (
        @FILE_ID, @CANAL, @CODIGO_CLIENTE, @NOMBRE_CUENTA, @NOMBRE_OBRA,
        @NOMBRE_COMPLETO, @CARGO, @ROL, @GENERO, @MOVIL,
        @DIRECCION, @MUNICIPIO, @DEPARTAMENTO, @ES_PUNTO_VENTA_PUBLICO,
        @HABEAS_DATA, @MEDIO_AUTORIZACION_HABEAS,
        @FECHA_AUTORIZACION_HABEAS, @HABEAS_DATA_FIRMADO
    );
END;
GO
