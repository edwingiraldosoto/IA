-- ============================================================
-- BASE DE DATOS: ferreterias_db
-- PROCEDIMIENTO: SP_ARGOS_MARCAR_PROCESADO
-- DESCRIPCION: Marca un registro individual de ARGOS_RECORDS
--              como procesado (PROCESSED=1). Llamado por el
--              backend despues de ejecutar exitosamente el
--              UPSERT del negocio y la insercion de contactos
--              en FERRETERIASARGOS y FERRETERIASARGOS_CONTACTOS.
-- PARAMETROS:
--   @ID - ID del registro en ARGOS_RECORDS
-- DOMINIO: ARGOS - Procesamiento
-- ============================================================
USE ferreterias_db;
GO

CREATE PROCEDURE [dbo].[SP_ARGOS_MARCAR_PROCESADO]
    @ID INT
AS
BEGIN
    SET NOCOUNT ON;

    UPDATE ARGOS_RECORDS
    SET PROCESSED = 1
    WHERE ID = @ID;
END;
GO
