-- ============================================================
-- BASE DE DATOS: ferreterias_db
-- PROCEDIMIENTO: SP_MAPA_LISTAR_NEGOCIOS
-- DESCRIPCION: Listado paginado de negocios de FerreteriasUnificadas
--              con multiples filtros opcionales. Devuelve los
--              campos esenciales para el mapa del frontend.
--              Ordena por SCORE DESC para mostrar primero los
--              negocios con mayor probabilidad de venta de
--              materiales de construccion. Usa parametros
--              OUTPUT para el total con filtros (para paginacion).
-- PARAMETROS:
--   @OFFSET, @LIMITE         - Paginacion (por defecto 0/20)
--   @DEPARTAMENTO, @MUNICIPIO - Filtros geograficos (NULL=todos)
--   @FUENTE                  - Filtro por fuente (RUES/APIFY/ARGOS)
--   @NIVEL_CONFIANZA         - Filtro por nivel AI (NULL=todos)
--   @VENDE_*                 - Filtros por material (NULL=todos)
--   @TOTAL_COUNT OUTPUT      - Total de registros con filtros
-- DOMINIO: Mapa / Negocios
-- ============================================================
USE ferreterias_db;
GO

CREATE PROCEDURE [dbo].[SP_MAPA_LISTAR_NEGOCIOS]
    @OFFSET          INT = 0,
    @LIMITE          INT = 20,
    @DEPARTAMENTO    NVARCHAR(100) = NULL,
    @MUNICIPIO       NVARCHAR(100) = NULL,
    @FUENTE          NVARCHAR(50)  = NULL,
    @NIVEL_CONFIANZA NVARCHAR(20)  = NULL,
    @VENDE_CEMENTO   BIT = NULL,
    @VENDE_TUBOS     BIT = NULL,
    @VENDE_VARILLAS  BIT = NULL,
    @VENDE_LADRILLOS BIT = NULL,
    @VENDE_AGREGADOS BIT = NULL,
    @TOTAL_COUNT     INT OUTPUT
AS
BEGIN
    SET NOCOUNT ON;

    -- Total con filtros (para paginacion en frontend)
    SELECT @TOTAL_COUNT = COUNT(*)
    FROM FerreteriasUnificadas
    WHERE
        (DEPARTAMENTO    = @DEPARTAMENTO    OR @DEPARTAMENTO    IS NULL)
        AND (MUNICIPIO   = @MUNICIPIO       OR @MUNICIPIO       IS NULL)
        AND (FUENTE      = @FUENTE          OR @FUENTE          IS NULL)
        AND (NIVEL_CONFIANZA = @NIVEL_CONFIANZA OR @NIVEL_CONFIANZA IS NULL)
        AND (VENDE_CEMENTO   = @VENDE_CEMENTO   OR @VENDE_CEMENTO   IS NULL)
        AND (VENDE_TUBOS     = @VENDE_TUBOS     OR @VENDE_TUBOS     IS NULL)
        AND (VENDE_VARILLAS  = @VENDE_VARILLAS  OR @VENDE_VARILLAS  IS NULL)
        AND (VENDE_LADRILLOS = @VENDE_LADRILLOS OR @VENDE_LADRILLOS IS NULL)
        AND (VENDE_AGREGADOS = @VENDE_AGREGADOS OR @VENDE_AGREGADOS IS NULL);

    -- Registros paginados
    SELECT ID, NOMBRE, LAT, LNG, TELEFONO, WHATSAPP, MUNICIPIO, DEPARTAMENTO,
           DIRECCION_COMERCIAL, VENDE_CEMENTO, VENDE_TUBOS, VENDE_VARILLAS,
           VENDE_LADRILLOS, VENDE_AGREGADOS, SCORE, NIVEL_CONFIANZA,
           MATERIALES_OBSERVADOS, URL_GOOGLE, FUENTE,
           ID_RUES, ID_APIFY, ID_ARGOS, CODIGO_CLIENTE_ARGOS, CANAL,
           NOMBRE_CUENTA, NOMBRE_OBRA, ES_PUNTO_VENTA_PUBLICO
    FROM FerreteriasUnificadas
    WHERE
        (DEPARTAMENTO    = @DEPARTAMENTO    OR @DEPARTAMENTO    IS NULL)
        AND (MUNICIPIO   = @MUNICIPIO       OR @MUNICIPIO       IS NULL)
        AND (FUENTE      = @FUENTE          OR @FUENTE          IS NULL)
        AND (NIVEL_CONFIANZA = @NIVEL_CONFIANZA OR @NIVEL_CONFIANZA IS NULL)
        AND (VENDE_CEMENTO   = @VENDE_CEMENTO   OR @VENDE_CEMENTO   IS NULL)
        AND (VENDE_TUBOS     = @VENDE_TUBOS     OR @VENDE_TUBOS     IS NULL)
        AND (VENDE_VARILLAS  = @VENDE_VARILLAS  OR @VENDE_VARILLAS  IS NULL)
        AND (VENDE_LADRILLOS = @VENDE_LADRILLOS OR @VENDE_LADRILLOS IS NULL)
        AND (VENDE_AGREGADOS = @VENDE_AGREGADOS OR @VENDE_AGREGADOS IS NULL)
    ORDER BY SCORE DESC, ID
    OFFSET @OFFSET ROWS FETCH NEXT @LIMITE ROWS ONLY;
END;
GO
