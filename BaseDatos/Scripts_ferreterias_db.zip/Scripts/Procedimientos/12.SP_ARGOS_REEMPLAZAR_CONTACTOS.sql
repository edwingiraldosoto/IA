-- ============================================================
-- BASE DE DATOS: ferreterias_db
-- PROCEDIMIENTO: SP_ARGOS_REEMPLAZAR_CONTACTOS
-- DESCRIPCION: Elimina TODOS los contactos existentes de una
--              ferreteria en FERRETERIASARGOS_CONTACTOS e
--              inserta el nuevo contacto en una sola operacion.
--              Patron "delete and replace" para el primer
--              contacto de cada lote de procesamiento.
--              Los contactos adicionales del mismo negocio
--              deben insertarse con SP_ARGOS_INSERTAR_CONTACTO.
-- PARAMETROS:
--   @FERRETERIA_ID - ID del negocio en FERRETERIASARGOS
--   Datos del contacto: nombre, cargo, rol, genero, movil,
--   habeas data y autorizaciones.
-- DOMINIO: ARGOS - Contactos
-- ============================================================
USE ferreterias_db;
GO

CREATE PROCEDURE [dbo].[SP_ARGOS_REEMPLAZAR_CONTACTOS]
    @FERRETERIA_ID              INT,
    @CODIGO_CLIENTE             NVARCHAR(50),
    @NOMBRE_COMPLETO            NVARCHAR(255),
    @CARGO                      NVARCHAR(100),
    @ROL                        NVARCHAR(100),
    @GENERO                     NVARCHAR(20),
    @MOVIL                      NVARCHAR(50),
    @HABEAS_DATA                BIT,
    @MEDIO_AUTORIZACION_HABEAS  NVARCHAR(255),
    @FECHA_AUTORIZACION_HABEAS  DATE,
    @HABEAS_DATA_FIRMADO        BIT
AS
BEGIN
    SET NOCOUNT ON;

    -- Elimina los contactos anteriores
    DELETE FROM FERRETERIASARGOS_CONTACTOS
    WHERE FERRETERIA_ID = @FERRETERIA_ID;

    -- Inserta el nuevo contacto
    INSERT INTO FERRETERIASARGOS_CONTACTOS (
        FERRETERIA_ID, CODIGO_CLIENTE,
        NOMBRE_COMPLETO, CARGO, ROL, GENERO, MOVIL,
        HABEAS_DATA, MEDIO_AUTORIZACION_HABEAS,
        FECHA_AUTORIZACION_HABEAS, HABEAS_DATA_FIRMADO
    ) VALUES (
        @FERRETERIA_ID, @CODIGO_CLIENTE,
        @NOMBRE_COMPLETO, @CARGO, @ROL, @GENERO, @MOVIL,
        @HABEAS_DATA, @MEDIO_AUTORIZACION_HABEAS,
        @FECHA_AUTORIZACION_HABEAS, @HABEAS_DATA_FIRMADO
    );
END;
GO
