-- ============================================================
-- BASE DE DATOS: ferreterias_db
-- PROCEDIMIENTO: SP_SYNC_OBTENER_JOB
-- DESCRIPCION: Retorna el estado actual completo de un job de
--              sincronizacion. Consumido por el frontend via
--              polling para mostrar el progreso del proceso de
--              unificacion (contadores por fuente, status,
--              mensaje de resultado).
-- PARAMETROS:
--   @JOB_ID - UUID del job a consultar
-- DOMINIO: Sincronizacion
-- ============================================================
USE ferreterias_db;
GO

CREATE PROCEDURE [dbo].[SP_SYNC_OBTENER_JOB]
    @JOB_ID NVARCHAR(50)
AS
BEGIN
    SET NOCOUNT ON;

    SELECT *
    FROM SyncJobs
    WHERE JOB_ID = @JOB_ID;
END;
GO
