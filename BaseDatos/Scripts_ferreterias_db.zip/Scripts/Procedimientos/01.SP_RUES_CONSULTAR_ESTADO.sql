-- ============================================================
-- BASE DE DATOS: ferreterias_db
-- PROCEDIMIENTO: SP_RUES_CONSULTAR_ESTADO
-- DESCRIPCION: Consulta el estado actual de un upload RUES y
--              el progreso de procesamiento de sus registros.
--              Devuelve dos result sets:
--              RS1 - Estado general del upload (status, filename,
--                    fecha_upload)
--              RS2 - Conteo total y procesados de RUES_RECORDS
--                    para ese FILE_ID.
--              Consumido por el frontend para mostrar barra de
--              progreso en tiempo real mediante polling.
-- PARAMETROS:
--   @FILE_ID  - UUID del archivo a consultar
-- DOMINIO: RUES - Uploads/Estado
-- ============================================================
USE ferreterias_db;
GO

CREATE PROCEDURE [dbo].[SP_RUES_CONSULTAR_ESTADO]
    @FILE_ID NVARCHAR(36)
AS
BEGIN
    SET NOCOUNT ON;

    -- Resultado 1: Estado del upload
    SELECT status, filename, CREATED_AT AS fecha_upload
    FROM rues_uploads
    WHERE file_id = @FILE_ID;

    -- Resultado 2: Conteos de registros
    SELECT
        COUNT(*) AS total,
        SUM(CASE WHEN processed = 1 THEN 1 ELSE 0 END) AS procesados
    FROM rues_records
    WHERE file_id = @FILE_ID;
END;
GO
