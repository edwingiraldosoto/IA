-- ============================================================
-- BASE DE DATOS: ferreterias_db
-- PROCEDIMIENTO: SP_RUES_VERIFICAR_Y_REGISTRAR_UPLOAD
-- DESCRIPCION: Verifica si un archivo Excel del RUES ya fue
--              procesado anteriormente comparando su hash SHA.
--              Si no existe un upload con el mismo hash en
--              estado 'processing' o 'completed', registra el
--              nuevo upload en RUES_UPLOADS con estado inicial
--              'processing'. Devuelve parametros OUTPUT con
--              @EXISTE (0=nuevo, 1=ya existe) y @STATUS_ANTERIOR.
-- PARAMETROS:
--   @FILE_ID           - UUID del archivo (entrada)
--   @FILENAME          - Nombre del archivo (entrada)
--   @HASH_ARCHIVO      - Hash MD5/SHA del archivo (entrada)
--   @EXISTE            - 0=archivo nuevo, 1=ya existe (salida)
--   @STATUS_ANTERIOR   - Estado previo si ya existe (salida)
-- DOMINIO: RUES - Uploads/Estado
-- ============================================================
USE ferreterias_db;
GO

CREATE PROCEDURE [dbo].[SP_RUES_VERIFICAR_Y_REGISTRAR_UPLOAD]
    @FILE_ID           NVARCHAR(36),
    @FILENAME          NVARCHAR(255),
    @HASH_ARCHIVO      NVARCHAR(32),
    @EXISTE            INT OUTPUT,
    @STATUS_ANTERIOR   NVARCHAR(20) OUTPUT
AS
BEGIN
    SET NOCOUNT ON;

    DECLARE @RowCount INT;

    SELECT @STATUS_ANTERIOR = status, @RowCount = COUNT(*)
    FROM rues_uploads
    WHERE hash_archivo = @HASH_ARCHIVO
      AND status IN ('processing', 'completed')
    GROUP BY status;

    SET @EXISTE = ISNULL(@RowCount, 0);

    IF @EXISTE = 0
    BEGIN
        INSERT INTO rues_uploads (file_id, filename, hash_archivo, status)
        VALUES (@FILE_ID, @FILENAME, @HASH_ARCHIVO, 'processing');
    END
END;
GO
