-- ============================================================
-- BASE DE DATOS: ferreterias_db
-- PROCEDIMIENTO: SP_ARGOS_ACTUALIZAR_ESTADO_UPLOAD
-- DESCRIPCION: Actualiza el campo STATUS de un upload en
--              ARGOS_UPLOADS. Usado por el backend para marcar
--              el upload como 'completed' o 'error' al terminar
--              el procesamiento del archivo ARGOS.
-- PARAMETROS:
--   @FILE_ID - UUID del archivo
--   @STATUS  - Nuevo estado ('processing'/'completed'/'error')
-- DOMINIO: ARGOS - Uploads/Estado
-- ============================================================
USE ferreterias_db;
GO

CREATE PROCEDURE [dbo].[SP_ARGOS_ACTUALIZAR_ESTADO_UPLOAD]
    @FILE_ID NVARCHAR(36),
    @STATUS  NVARCHAR(20)
AS
BEGIN
    SET NOCOUNT ON;

    UPDATE ARGOS_UPLOADS
    SET STATUS = @STATUS
    WHERE file_id = @FILE_ID;
END;
GO
