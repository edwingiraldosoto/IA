-- ============================================================
-- BASE DE DATOS: ferreterias_db
-- PROCEDIMIENTO: SP_ARGOS_BORRAR_CONTACTOS
-- DESCRIPCION: Elimina TODOS los contactos de una ferreteria
--              en FERRETERIASARGOS_CONTACTOS. Operacion de
--              limpieza independiente, a diferencia de
--              SP_ARGOS_REEMPLAZAR_CONTACTOS que borra e
--              inserta en la misma llamada.
-- PARAMETROS:
--   @FERRETERIA_ID - ID del negocio en FERRETERIASARGOS
-- DOMINIO: ARGOS - Contactos
-- ============================================================
USE ferreterias_db;
GO

CREATE PROCEDURE [dbo].[SP_ARGOS_BORRAR_CONTACTOS]
    @FERRETERIA_ID INT
AS
BEGIN
    SET NOCOUNT ON;

    DELETE FROM FERRETERIASARGOS_CONTACTOS
    WHERE FERRETERIA_ID = @FERRETERIA_ID;
END;
GO
