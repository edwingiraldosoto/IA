-- ============================================================
-- BASE DE DATOS: ferreterias_db
-- PROCEDIMIENTO: SP_SYNC_ACTUALIZAR_JOB
-- DESCRIPCION: Actualiza el estado y contadores de un job de
--              sincronizacion. Todos los parametros numericos
--              son opcionales (NULL = no actualizar ese campo).
--              Usa ISNULL(@param, columna) para actualizar solo
--              los campos enviados. Cuando STATUS es 'completado'
--              o 'error', registra automaticamente FECHA_FIN.
-- PARAMETROS:
--   @JOB_ID         - UUID del job (requerido)
--   @STATUS         - Nuevo estado (requerido)
--   @TOTAL_RUES     - Total registros RUES procesados (opcional)
--   @TOTAL_APIFY    - Total registros Apify procesados (opcional)
--   @TOTAL_UNIFICADOS - Total negocios unificados (opcional)
--   @TOTAL_SOLO_RUES  - Solo en RUES, sin match (opcional)
--   @TOTAL_SOLO_APIFY - Solo en Apify, sin match (opcional)
--   @TOTAL_ARGOS      - Total registros ARGOS (opcional)
--   @TOTAL_SOLO_ARGOS - Solo en ARGOS, sin match (opcional)
--   @MENSAJE          - Mensaje descriptivo (opcional)
-- DOMINIO: Sincronizacion
-- ============================================================
USE ferreterias_db;
GO

CREATE PROCEDURE [dbo].[SP_SYNC_ACTUALIZAR_JOB]
    @JOB_ID           NVARCHAR(50),
    @STATUS           NVARCHAR(20),
    @TOTAL_RUES       INT = NULL,
    @TOTAL_APIFY      INT = NULL,
    @TOTAL_UNIFICADOS INT = NULL,
    @TOTAL_SOLO_RUES  INT = NULL,
    @TOTAL_SOLO_APIFY INT = NULL,
    @TOTAL_ARGOS      INT = NULL,
    @TOTAL_SOLO_ARGOS INT = NULL,
    @MENSAJE          NVARCHAR(500) = NULL
AS
BEGIN
    SET NOCOUNT ON;

    UPDATE SyncJobs
    SET
        STATUS            = @STATUS,
        TOTAL_RUES        = ISNULL(@TOTAL_RUES, TOTAL_RUES),
        TOTAL_APIFY       = ISNULL(@TOTAL_APIFY, TOTAL_APIFY),
        TOTAL_UNIFICADOS  = ISNULL(@TOTAL_UNIFICADOS, TOTAL_UNIFICADOS),
        TOTAL_SOLO_RUES   = ISNULL(@TOTAL_SOLO_RUES, TOTAL_SOLO_RUES),
        TOTAL_SOLO_APIFY  = ISNULL(@TOTAL_SOLO_APIFY, TOTAL_SOLO_APIFY),
        TOTAL_ARGOS       = ISNULL(@TOTAL_ARGOS, TOTAL_ARGOS),
        TOTAL_SOLO_ARGOS  = ISNULL(@TOTAL_SOLO_ARGOS, TOTAL_SOLO_ARGOS),
        MENSAJE           = ISNULL(@MENSAJE, MENSAJE),
        FECHA_FIN         = CASE
                                WHEN @STATUS IN ('completado', 'error') THEN GETDATE()
                                ELSE FECHA_FIN
                            END
    WHERE JOB_ID = @JOB_ID;
END;
GO
