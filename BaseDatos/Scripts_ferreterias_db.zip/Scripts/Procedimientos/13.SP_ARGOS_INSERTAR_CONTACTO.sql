-- ============================================================
-- BASE DE DATOS: ferreterias_db
-- PROCEDIMIENTO: SP_ARGOS_INSERTAR_CONTACTO
-- DESCRIPCION: Inserta un contacto adicional en
--              FERRETERIASARGOS_CONTACTOS SIN eliminar los
--              existentes. Usado para el segundo contacto en
--              adelante de un mismo negocio, despues de que
--              SP_ARGOS_REEMPLAZAR_CONTACTOS ya registro el
--              primer contacto del lote.
-- PARAMETROS:
--   @FERRETERIA_ID - ID del negocio en FERRETERIASARGOS
--   Datos del contacto adicional.
-- DOMINIO: ARGOS - Contactos
-- ============================================================
USE ferreterias_db;
GO

CREATE PROCEDURE [dbo].[SP_ARGOS_INSERTAR_CONTACTO]
    @FERRETERIA_ID              INT,
    @CODIGO_CLIENTE             NVARCHAR(50),
    @NOMBRE_COMPLETO            NVARCHAR(255),
    @CARGO                      NVARCHAR(100),
    @ROL                        NVARCHAR(100),
    @GENERO                     NVARCHAR(20),
    @MOVIL                      NVARCHAR(50),
    @HABEAS_DATA                BIT,
    @MEDIO_AUTORIZACION_HABEAS  NVARCHAR(255),
    @FECHA_AUTORIZACION_HABEAS  DATE,
    @HABEAS_DATA_FIRMADO        BIT
AS
BEGIN
    SET NOCOUNT ON;

    INSERT INTO FERRETERIASARGOS_CONTACTOS (
        FERRETERIA_ID, CODIGO_CLIENTE,
        NOMBRE_COMPLETO, CARGO, ROL, GENERO, MOVIL,
        HABEAS_DATA, MEDIO_AUTORIZACION_HABEAS,
        FECHA_AUTORIZACION_HABEAS, HABEAS_DATA_FIRMADO
    ) VALUES (
        @FERRETERIA_ID, @CODIGO_CLIENTE,
        @NOMBRE_COMPLETO, @CARGO, @ROL, @GENERO, @MOVIL,
        @HABEAS_DATA, @MEDIO_AUTORIZACION_HABEAS,
        @FECHA_AUTORIZACION_HABEAS, @HABEAS_DATA_FIRMADO
    );
END;
GO
