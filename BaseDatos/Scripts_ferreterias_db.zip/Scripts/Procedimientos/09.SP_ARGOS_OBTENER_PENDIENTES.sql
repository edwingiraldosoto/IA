-- ============================================================
-- BASE DE DATOS: ferreterias_db
-- PROCEDIMIENTO: SP_ARGOS_OBTENER_PENDIENTES
-- DESCRIPCION: Retorna todos los registros de ARGOS_RECORDS
--              de un archivo dado que aun no han sido procesados
--              (PROCESSED=0). El backend los itera para construir
--              o actualizar los negocios en FERRETERIASARGOS.
--              Ordenado por CODIGO_CLIENTE y NOMBRE_COMPLETO
--              para agrupar los contactos del mismo negocio.
-- PARAMETROS:
--   @FILE_ID - UUID del archivo ARGOS a procesar
-- DOMINIO: ARGOS - Procesamiento
-- ============================================================
USE ferreterias_db;
GO

CREATE PROCEDURE [dbo].[SP_ARGOS_OBTENER_PENDIENTES]
    @FILE_ID NVARCHAR(36)
AS
BEGIN
    SET NOCOUNT ON;

    SELECT *
    FROM ARGOS_RECORDS
    WHERE FILE_ID = @FILE_ID
      AND PROCESSED = 0
    ORDER BY CODIGO_CLIENTE, NOMBRE_COMPLETO;
END;
GO
