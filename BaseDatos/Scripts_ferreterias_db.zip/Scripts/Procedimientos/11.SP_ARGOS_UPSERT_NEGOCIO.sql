-- ============================================================
-- BASE DE DATOS: ferreterias_db
-- PROCEDIMIENTO: SP_ARGOS_UPSERT_NEGOCIO
-- DESCRIPCION: UPSERT de un negocio ARGOS en FERRETERIASARGOS.
--              Intenta UPDATE por CODIGO_CLIENTE primero;
--              si no afecta filas, hace INSERT con FUENTE='ARGOS'.
--              Al finalizar retorna el ID resultante (nuevo o
--              existente) para que el backend pueda asociar
--              los contactos. Es el procedimiento central del
--              pipeline de procesamiento ARGOS.
-- PARAMETROS: Todos los campos del negocio incluyendo datos
--             ARGOS (canal, nombre cuenta, obra) y datos de
--             analisis AI (score, materiales, nivel confianza).
-- RETORNA: Result set con ID del negocio en FERRETERIASARGOS
-- DOMINIO: ARGOS - Procesamiento
-- ============================================================
USE ferreterias_db;
GO

CREATE PROCEDURE [dbo].[SP_ARGOS_UPSERT_NEGOCIO]
    @CODIGO_CLIENTE         NVARCHAR(50),
    @CANAL                  NVARCHAR(50),
    @NOMBRE_CUENTA          NVARCHAR(255),
    @NOMBRE_OBRA            NVARCHAR(255),
    @NOMBRE                 NVARCHAR(255),
    @DIRECCION              NVARCHAR(500),
    @MUNICIPIO              NVARCHAR(100),
    @DEPARTAMENTO           NVARCHAR(100),
    @ES_PUNTO_VENTA_PUBLICO BIT,
    @LAT                    DECIMAL(10,7),
    @LNG                    DECIMAL(10,7),
    @TELEFONO               NVARCHAR(50),
    @WHATSAPP               NVARCHAR(50),
    @VENDE_CEMENTO          BIT,
    @VENDE_TUBOS            BIT,
    @VENDE_VARILLAS         BIT,
    @VENDE_LADRILLOS        BIT,
    @VENDE_AGREGADOS        BIT,
    @SCORE                  INT,
    @MATERIALES_OBSERVADOS  NVARCHAR(500),
    @NIVEL_CONFIANZA        NVARCHAR(20),
    @URL_GOOGLE             NVARCHAR(500),
    @ULTIMO_ANALISIS        DATETIME
AS
BEGIN
    SET NOCOUNT ON;

    -- Intenta UPDATE primero
    UPDATE FERRETERIASARGOS SET
        NOMBRE                = @NOMBRE,
        LAT                   = @LAT,
        LNG                   = @LNG,
        TELEFONO              = @TELEFONO,
        WHATSAPP              = @WHATSAPP,
        VENDE_CEMENTO         = @VENDE_CEMENTO,
        VENDE_TUBOS           = @VENDE_TUBOS,
        VENDE_VARILLAS        = @VENDE_VARILLAS,
        VENDE_LADRILLOS       = @VENDE_LADRILLOS,
        VENDE_AGREGADOS       = @VENDE_AGREGADOS,
        SCORE                 = @SCORE,
        MATERIALES_OBSERVADOS = @MATERIALES_OBSERVADOS,
        NIVEL_CONFIANZA       = @NIVEL_CONFIANZA,
        URL_GOOGLE            = @URL_GOOGLE,
        FECHA_ACTUALIZACION   = GETDATE(),
        ULTIMO_ANALISIS       = @ULTIMO_ANALISIS
    WHERE CODIGO_CLIENTE = @CODIGO_CLIENTE;

    -- Si no actualizo nada, inserta
    IF @@ROWCOUNT = 0
    BEGIN
        INSERT INTO FERRETERIASARGOS (
            CODIGO_CLIENTE, CANAL, NOMBRE_CUENTA, NOMBRE_OBRA,
            NOMBRE, DIRECCION, MUNICIPIO, DEPARTAMENTO,
            ES_PUNTO_VENTA_PUBLICO, LAT, LNG,
            TELEFONO, WHATSAPP,
            VENDE_CEMENTO, VENDE_TUBOS, VENDE_VARILLAS,
            VENDE_LADRILLOS, VENDE_AGREGADOS, SCORE,
            MATERIALES_OBSERVADOS, NIVEL_CONFIANZA,
            URL_GOOGLE, FUENTE, ULTIMO_ANALISIS
        ) VALUES (
            @CODIGO_CLIENTE, @CANAL, @NOMBRE_CUENTA, @NOMBRE_OBRA,
            @NOMBRE, @DIRECCION, @MUNICIPIO, @DEPARTAMENTO,
            @ES_PUNTO_VENTA_PUBLICO, @LAT, @LNG,
            @TELEFONO, @WHATSAPP,
            @VENDE_CEMENTO, @VENDE_TUBOS, @VENDE_VARILLAS,
            @VENDE_LADRILLOS, @VENDE_AGREGADOS, @SCORE,
            @MATERIALES_OBSERVADOS, @NIVEL_CONFIANZA,
            @URL_GOOGLE, 'ARGOS', @ULTIMO_ANALISIS
        );
    END

    -- Retorna el ID resultante
    SELECT ID
    FROM FERRETERIASARGOS
    WHERE CODIGO_CLIENTE = @CODIGO_CLIENTE;
END;
GO
