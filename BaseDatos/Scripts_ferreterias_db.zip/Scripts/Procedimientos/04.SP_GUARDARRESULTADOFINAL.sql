-- ============================================================
-- BASE DE DATOS: ferreterias_db
-- PROCEDIMIENTO: SP_GUARDARRESULTADOFINAL
-- DESCRIPCION: UPSERT (MERGE) de una ferreteria procesada del
--              RUES en la tabla FERRETERIASRUES. Si ya existe
--              un registro con el mismo NIT (NUMERO_IDENTIFICACION_RUES),
--              actualiza los campos de analisis AI (materiales,
--              score, coordenadas). Si no existe, inserta un
--              nuevo registro con todos los campos del RUES y
--              el resultado del analisis.
--              Es el procedimiento central del pipeline de
--              scraping Node.js / Gemini AI para la fuente RUES.
-- PARAMETROS: Datos completos del negocio (RUES + analisis AI)
-- DOMINIO: RUES - Resultado final
-- ============================================================
USE ferreterias_db;
GO

CREATE PROCEDURE [dbo].[SP_GUARDARRESULTADOFINAL]
    @NOMBRE         NVARCHAR(255),
    @TELEFONO       NVARCHAR(50),
    @WHATSAPP       NVARCHAR(50),
    @NIT            NVARCHAR(50),
    @LAT            DECIMAL(10,7),
    @LNG            DECIMAL(10,7),
    @VENDE_CEMENTO  BIT,
    @VENDE_TUBOS    BIT,
    @VENDE_VARILLAS BIT,
    @VENDE_LADRILLOS BIT,
    @VENDE_AGREGADOS BIT,
    @SCORE          INT,
    @MATERIALES     NVARCHAR(500),
    @CONFIANZA      NVARCHAR(20),
    @RAZON_SOCIAL   NVARCHAR(500),
    @TIPO_ID        NVARCHAR(50),
    @NUMERO_ID      NVARCHAR(50),
    @DEPARTAMENTO   NVARCHAR(100),
    @MUNICIPIO      NVARCHAR(100),
    @DIRECCION      NVARCHAR(500),
    @CORREO         NVARCHAR(255),
    @REP_LEGAL      NVARCHAR(255)
AS
BEGIN
    MERGE FERRETERIASRUES AS T
    USING (SELECT @NIT AS nit) AS S
        ON T.NUMERO_IDENTIFICACION_RUES = S.nit
    WHEN MATCHED THEN
        UPDATE SET
            NOMBRE                = @NOMBRE,
            TELEFONO              = @TELEFONO,
            WHATSAPP              = @WHATSAPP,
            LAT                   = @LAT,
            LNG                   = @LNG,
            VENDE_CEMENTO         = @VENDE_CEMENTO,
            VENDE_TUBOS           = @VENDE_TUBOS,
            VENDE_VARILLAS        = @VENDE_VARILLAS,
            VENDE_LADRILLOS       = @VENDE_LADRILLOS,
            VENDE_AGREGADOS       = @VENDE_AGREGADOS,
            SCORE                 = @SCORE,
            MATERIALES_OBSERVADOS = @MATERIALES,
            NIVEL_CONFIANZA       = @CONFIANZA,
            ULTIMO_ANALISIS       = GETDATE(),
            FECHA_ACTUALIZACION   = GETDATE()
    WHEN NOT MATCHED THEN
        INSERT (
            NOMBRE, TELEFONO, WHATSAPP, NIT, LAT, LNG,
            VENDE_CEMENTO, VENDE_TUBOS, VENDE_VARILLAS,
            VENDE_LADRILLOS, VENDE_AGREGADOS, SCORE,
            MATERIALES_OBSERVADOS, NIVEL_CONFIANZA, ULTIMO_ANALISIS,
            RAZON_SOCIAL_RUES, TIPO_IDENTIFICACION_RUES,
            NUMERO_IDENTIFICACION_RUES, DEPARTAMENTO_RUES,
            MUNICIPIO_RUES, DIRECCION_COMERCIAL_RUES,
            CORREO_COMERCIAL_RUES, REP_LEGAL_RUES
        ) VALUES (
            @NOMBRE, @TELEFONO, @WHATSAPP, @NIT, @LAT, @LNG,
            @VENDE_CEMENTO, @VENDE_TUBOS, @VENDE_VARILLAS,
            @VENDE_LADRILLOS, @VENDE_AGREGADOS, @SCORE,
            @MATERIALES, @CONFIANZA, GETDATE(),
            @RAZON_SOCIAL, @TIPO_ID, @NUMERO_ID,
            @DEPARTAMENTO, @MUNICIPIO, @DIRECCION,
            @CORREO, @REP_LEGAL
        );
END;
GO
