-- ============================================================
-- BASE DE DATOS: ferreterias_db
-- PROCEDIMIENTO: SP_INSERTARREGISTRORUES
-- DESCRIPCION: Inserta un registro individual de empresa del
--              RUES en RUES_RECORDS. Llamado de forma masiva
--              por el backend al procesar cada fila del Excel
--              cargado. Las coordenadas LAT/LNG pueden venir
--              nulas si aun no se ha geocodificado la direccion.
-- PARAMETROS: Todos los campos de RUES_RECORDS excepto
--             RECORD_ID (identity), PROCESSED y PROCESSED_AT.
-- DOMINIO: RUES - Carga masiva
-- ============================================================
USE ferreterias_db;
GO

CREATE PROCEDURE [dbo].[SP_INSERTARREGISTRORUES]
    @FILE_ID               VARCHAR(36),
    @RAZON_SOCIAL          VARCHAR(500),
    @NUMERO_IDENTIFICACION VARCHAR(50),
    @TIPO_IDENTIFICACION   VARCHAR(50),
    @DEPARTAMENTO          VARCHAR(100),
    @MUNICIPIO             VARCHAR(100),
    @DIRECCION_COMERCIAL   VARCHAR(500),
    @CORREO_COMERCIAL      VARCHAR(255),
    @REP_LEGAL             VARCHAR(255),
    @LATITUD               DECIMAL(10,7),
    @LONGITUD              DECIMAL(10,7)
AS
BEGIN
    INSERT INTO RUES_RECORDS (
        FILE_ID, RAZON_SOCIAL, NUMERO_IDENTIFICACION, TIPO_IDENTIFICACION,
        DEPARTAMENTO, MUNICIPIO, DIRECCION_COMERCIAL, CORREO_COMERCIAL,
        REP_LEGAL, LATITUD, LONGITUD
    ) VALUES (
        @FILE_ID, @RAZON_SOCIAL, @NUMERO_IDENTIFICACION, @TIPO_IDENTIFICACION,
        @DEPARTAMENTO, @MUNICIPIO, @DIRECCION_COMERCIAL, @CORREO_COMERCIAL,
        @REP_LEGAL, @LATITUD, @LONGITUD
    );
END;
GO
