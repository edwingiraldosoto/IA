-- ============================================================
-- BASE DE DATOS: ferreterias_db
-- PROCEDIMIENTO: SP_MAPA_DETALLE_NEGOCIO
-- DESCRIPCION: Retorna todos los campos de un negocio especifico
--              en FerreteriasUnificadas por su ID. Llamado cuando
--              el usuario hace clic en un marcador del mapa para
--              ver el detalle completo del negocio (datos de
--              contacto, RUES, ARGOS, analisis AI).
-- PARAMETROS:
--   @NEGOCIO_ID - ID del negocio en FerreteriasUnificadas
-- DOMINIO: Mapa / Negocios
-- ============================================================
USE ferreterias_db;
GO

CREATE PROCEDURE [dbo].[SP_MAPA_DETALLE_NEGOCIO]
    @NEGOCIO_ID INT
AS
BEGIN
    SET NOCOUNT ON;

    SELECT *
    FROM FerreteriasUnificadas
    WHERE ID = @NEGOCIO_ID;
END;
GO
