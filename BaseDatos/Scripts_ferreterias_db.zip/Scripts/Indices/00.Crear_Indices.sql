-- ============================================================
-- BASE DE DATOS: ferreterias_db
-- INDICES DE USUARIO
-- DESCRIPCION: Indices no clusterizados creados para optimizar
--              las consultas mas frecuentes del sistema.
-- ============================================================
USE ferreterias_db;
GO

-- ─────────────────────────────────────────────────────────────
-- IX_RUES_UPLOADS_HASH
-- Tabla: RUES_UPLOADS
-- Columna: HASH_ARCHIVO
-- Proposito: Acelera la busqueda por hash de archivo para
--            detectar duplicados en SP_RUES_VERIFICAR_Y_REGISTRAR_UPLOAD
-- ─────────────────────────────────────────────────────────────
CREATE INDEX [IX_RUES_UPLOADS_HASH]
    ON [dbo].[RUES_UPLOADS] ([HASH_ARCHIVO]);
GO

-- ─────────────────────────────────────────────────────────────
-- IX_FU_CONTACTOS_UNIFICADA_ID
-- Tabla: FerreteriasUnificadas_Contactos
-- Columna: FERRETERIA_UNIFICADA_ID
-- Proposito: Acelera la busqueda de contactos por ferreteria
--            unificada (JOINs frecuentes desde el frontend)
-- ─────────────────────────────────────────────────────────────
CREATE INDEX [IX_FU_CONTACTOS_UNIFICADA_ID]
    ON [dbo].[FerreteriasUnificadas_Contactos] ([FERRETERIA_UNIFICADA_ID]);
GO

-- ─────────────────────────────────────────────────────────────
-- IX_DESCARTADOS_JOB_ID
-- Tabla: SyncJobs_Descartados
-- Columna: JOB_ID
-- Proposito: Acelera la consulta de descartados por job de
--            sincronizacion para reportes de auditoria
-- ─────────────────────────────────────────────────────────────
CREATE INDEX [IX_DESCARTADOS_JOB_ID]
    ON [dbo].[SyncJobs_Descartados] ([JOB_ID]);
GO
