-- ============================================================
-- BASE DE DATOS: ferreterias_db
-- VISTA: VW_FERRETERIAS_CEMENTO
-- DESCRIPCION: Vista de reporte rapido que expone unicamente
--              las ferreterias que venden cemento, con los
--              indicadores de materiales en formato texto
--              (SI/NO en lugar de bits). Simplifica las
--              consultas de reporteria sin necesidad de hacer
--              CASE en cada consulta ad-hoc.
-- NOTA: Apunta a la tabla FERRETERIAS (nombre original antes
--       de la evolucion a FERRETERIASRUES). Verificar que
--       la tabla referenciada existe en el ambiente objetivo.
-- ============================================================
USE ferreterias_db;
GO

CREATE VIEW [dbo].[VW_FERRETERIAS_CEMENTO] AS
SELECT
    NOMBRE,
    TELEFONO,
    WHATSAPP,
    NIT,
    LAT,
    LNG,
    CASE WHEN VENDE_CEMENTO   = 1 THEN 'SI' ELSE 'NO' END AS VENDE_CEMENTO_TXT,
    CASE WHEN VENDE_TUBOS     = 1 THEN 'SI' ELSE 'NO' END AS VENDE_TUBOS_TXT,
    CASE WHEN VENDE_VARILLAS  = 1 THEN 'SI' ELSE 'NO' END AS VENDE_VARILLAS_TXT,
    SCORE,
    MATERIALES_OBSERVADOS,
    FECHA_CREACION,
    FECHA_ACTUALIZACION
FROM FERRETERIAS
WHERE VENDE_CEMENTO = 1;
GO
